package com.example.schoolsignreminder

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import com.google.android.gms.location.*
import java.util.Calendar

class LocationMonitorService : Service() {
    private val prefs by lazy { getSharedPreferences("school", MODE_PRIVATE) }
    private lateinit var client: FusedLocationProviderClient
    private var wasInside: Boolean? = null
    private var lastAlertAt = 0L
    private val channelId = "school_sign_reminder"
    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) { result.lastLocation?.let { checkLocation(it) } }
    }
    override fun onCreate() { super.onCreate(); client=LocationServices.getFusedLocationProviderClient(this); createChannel(); startAsForeground(); requestUpdates() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if(!prefs.getBoolean("enabled",false)){stopSelf();return START_NOT_STICKY}; return START_STICKY }
    private fun createChannel() { if(Build.VERSION.SDK_INT>=26) { val nm=getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel(channelId,"تذكير توقيع المدرسة",NotificationManager.IMPORTANCE_HIGH).apply { description="تنبيهات مغادرة نطاق المدرسة" }) } }
    private fun startAsForeground() { val n=Notification.Builder(this,channelId).setSmallIcon(android.R.drawable.ic_dialog_map).setContentTitle("تذكير توقيع المدرسة").setContentText("مراقبة نطاق المدرسة مفعّلة").setOngoing(true).build(); if(Build.VERSION.SDK_INT>=29) startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(1,n) }
    private fun requestUpdates() { try { val req=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,45_000L).setMinUpdateIntervalMillis(25_000L).build(); client.requestLocationUpdates(req,callback,mainLooper) } catch (_:SecurityException) { stopSelf() } }
    private fun checkLocation(loc: Location) {
        if(!prefs.getBoolean("enabled",false)) return
        if(!prefs.getBoolean("hasLocation",false)) return
        val target=Location("school").apply { latitude=prefs.getFloat("lat",0f).toDouble(); longitude=prefs.getFloat("lng",0f).toDouble() }
        val distance=loc.distanceTo(target); val inside=distance <= prefs.getInt("radius",100)
        if(wasInside==null) { wasInside=inside; return }
        if(wasInside==true && !inside && isWithinSchedule() && System.currentTimeMillis()-lastAlertAt>15*60*1000L) { sendAlert(); lastAlertAt=System.currentTimeMillis() }
        wasInside=inside
    }
    private fun isWithinSchedule(): Boolean { val c=Calendar.getInstance(); val day=c.get(Calendar.DAY_OF_WEEK); val index=when(day){Calendar.SUNDAY->0;Calendar.MONDAY->1;Calendar.TUESDAY->2;Calendar.WEDNESDAY->3;Calendar.THURSDAY->4;Calendar.FRIDAY->5;else->6}; if(!prefs.getBoolean("day$index",index in 0..4)) return false; val minute=c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE); return minute in (11*60)..(13*60) }
    private fun sendAlert() { val n=Notification.Builder(this,channelId).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("تذكير توقيع الانصراف").setContentText("تأكد من توقيع الانصراف قبل مغادرة المدرسة.").setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).build(); getSystemService(NotificationManager::class.java).notify(2,n) }
    override fun onDestroy() { try { client.removeLocationUpdates(callback) } catch (_:Exception){}; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
