package com.example.schoolsignreminder

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("school", MODE_PRIVATE) }
    private lateinit var map: WebView
    private lateinit var radius: SeekBar
    private lateinit var radiusLabel: TextView
    private lateinit var status: TextView
    private val dayChecks = linkedMapOf<Int, CheckBox>()
    private val dayNames = listOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadMap()
        updateStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 10, 14, 10); setBackgroundColor(Color.rgb(248,250,252)) }
        val title = TextView(this).apply { text = "تذكير توقيع المدرسة"; textSize = 23f; setTextColor(Color.rgb(20,45,75)); gravity = Gravity.CENTER; setPadding(4,8,4,10) }
        root.addView(title)
        root.addView(TextView(this).apply { text = "حدد المدرسة على الخريطة بالضغط على موقعها"; textSize = 15f; gravity = Gravity.CENTER; setPadding(0,0,0,8) })
        map = WebView(this).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; webChromeClient = WebChromeClient(); webViewClient = WebViewClient(); addJavascriptInterface(MapBridge(), "AndroidBridge") }
        root.addView(map, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.2f))
        radiusLabel = TextView(this).apply { textSize = 16f; setPadding(0,8,0,0) }; root.addView(radiusLabel)
        radius = SeekBar(this).apply { max = 490; progress = (prefs.getInt("radius",100)-10).coerceIn(0,490); setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){ val m=p+10; radiusLabel.text="نطاق الخروج: $m متر"; map.evaluateJavascript("if(window.updateRadius)updateRadius($m)",null); prefs.edit().putInt("radius",m).apply() }; override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){} }) }
        root.addView(radius)
        root.addView(TextView(this).apply { text = "أيام التنبيه"; textSize = 16f; setPadding(0,8,0,3) })
        val daysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 7f }
        dayNames.forEachIndexed { index, name -> val cb=CheckBox(this).apply { text=name; textSize=10f; isChecked=prefs.getBoolean("day$index", index in 0..4); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("day$index",checked).apply() } }; dayChecks[index]=cb; daysRow.addView(cb,LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f)) }
        root.addView(daysRow)
        root.addView(TextView(this).apply { text = "وقت التنبيه: من 11:00 صباحًا إلى 1:00 ظهرًا"; textSize = 15f; setPadding(0,8,0,8) })
        status = TextView(this).apply { textSize=13f; gravity=Gravity.CENTER; setPadding(0,4,0,6) }; root.addView(status)
        val start = Button(this).apply { text="تفعيل مراقبة الخروج"; setOnClickListener { saveAndStart() } }; root.addView(start)
        val stop = Button(this).apply { text="إيقاف التنبيه"; setOnClickListener { stopService(Intent(this@MainActivity, LocationMonitorService::class.java)); prefs.edit().putBoolean("enabled",false).apply(); updateStatus() } }; root.addView(stop)
        setContentView(root)
        radiusLabel.text="نطاق الخروج: ${radius.progress+10} متر"
    }

    private fun loadMap() { map.loadUrl("file:///android_asset/map.html") }
    inner class MapBridge {
        @JavascriptInterface fun setLocation(lat: Double, lng: Double) { prefs.edit().putFloat("lat",lat.toFloat()).putFloat("lng",lng.toFloat()).putBoolean("hasLocation",true).apply(); runOnUiThread { status.text="تم تحديد موقع المدرسة: %.5f, %.5f".format(lat,lng) } }
        @JavascriptInterface fun getRadius(): Int = prefs.getInt("radius",100)
    }

    private fun saveAndStart() {
        if (!prefs.getBoolean("hasLocation",false)) { AlertDialog.Builder(this).setMessage("حدد موقع المدرسة بالضغط على الخريطة أولًا.").setPositiveButton("حسنًا",null).show(); return }
        val needed = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { ContextCompat.checkSelfPermission(this,it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { ActivityCompat.requestPermissions(this,missing.toTypedArray(),77); return }
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this).setTitle("السماح بالموقع في الخلفية").setMessage("للتنبيه عند إغلاق الشاشة، افتح إعدادات التطبيق > الأذونات > الموقع، واختر السماح طوال الوقت إن ظهر. بعد ذلك ارجع واضغط تفعيل مراقبة الخروج.").setPositiveButton("فتح الإعدادات") { _,_ -> startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))) }.setNegativeButton("لاحقًا",null).show(); return
        }
        prefs.edit().putBoolean("enabled",true).apply()
        ContextCompat.startForegroundService(this,Intent(this,LocationMonitorService::class.java))
        updateStatus()
    }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) { super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==77 && grantResults.isNotEmpty() && grantResults.all{it==PackageManager.PERMISSION_GRANTED}) saveAndStart() }
    private fun updateStatus() { status.text=if(prefs.getBoolean("enabled",false)) "المراقبة مفعّلة — التذكير بين 11 و1" else "المراقبة متوقفة" }
}
